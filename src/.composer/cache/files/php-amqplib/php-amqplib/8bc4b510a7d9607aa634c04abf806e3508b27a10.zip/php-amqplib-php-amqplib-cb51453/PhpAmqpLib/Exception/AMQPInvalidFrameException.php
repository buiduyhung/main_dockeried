<?php

namespace PhpAmqpLib\Exception;

class AMQPInvalidFrameException extends AMQPRuntimeException
{
}
